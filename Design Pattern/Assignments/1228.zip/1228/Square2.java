public class Square2 implements Shape{
    double len;
    public Square2(double len){
        this.len = len;
    }

    @Override
    public double getArea() {
        return len*len;
    }
}
