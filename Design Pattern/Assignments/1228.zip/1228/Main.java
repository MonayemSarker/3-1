import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        Shape rectangle = new Rectangle(3,4);
        double Area1 = rectangle.getArea();
        System.out.println(Area1);

        Rectangle square = new Square(9.9);
        double Area2 = square.getArea();
        System.out.println(Area2);

        Shape square2 = new Square2(9.9);
        double Area3 = square2.getArea();
        System.out.println(Area3);
    }
}