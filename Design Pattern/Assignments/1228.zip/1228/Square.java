public class Square extends Rectangle {
    public Square(double len) {
        super(len,len);
    }

    public double getArea(){
        return super.getArea();
    }

}
